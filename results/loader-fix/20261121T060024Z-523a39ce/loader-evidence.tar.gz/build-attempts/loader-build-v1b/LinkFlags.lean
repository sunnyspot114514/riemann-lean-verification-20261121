import Lean.Compiler.FFI
def main (args : List String) : IO Unit := do
  let root : System.FilePath := args.headD ""
  for arg in Lean.Compiler.FFI.getInternalLinkerFlags root do
    IO.println arg
